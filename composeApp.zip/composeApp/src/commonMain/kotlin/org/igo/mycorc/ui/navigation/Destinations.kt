package org.igo.mycorc.ui.navigation

object Destinations {
    const val DASHBOARD = "DASHBOARD"
    const val FACILITIES = "FACILITIES"
    const val SETTINGS = "SETTINGS"
    const val PROFILE = "PROFILE"
    const val CREATE_NOTE = "CREATE_NOTE"
}
