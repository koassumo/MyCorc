package org.igo.mycorc.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class NoteDto(val id: String)
