package org.igo.mycorc.core.error
