package org.igo.mycorc.data.mapper

class NoteDtoMapper
