package org.igo.mycorc.domain.usecase

class GetNoteDetailsUseCase
