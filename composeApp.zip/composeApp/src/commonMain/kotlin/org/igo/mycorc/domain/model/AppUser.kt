﻿package org.igo.mycorc.domain.model

data class AppUser(
    val id: String,
    val email: String?
)
